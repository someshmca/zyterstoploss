
export const CLAIM_BASIS_CONSTANT={
    values: [
    "12/12",
    "12/15",
    "12/18",
    "15/12",
    "24/12"
    ]
}