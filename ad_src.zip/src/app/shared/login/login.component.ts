import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import {Observable } from 'rxjs';
import {LoginService} from '../services/login.service';
import {LoginModel, LoginResponseModel} from  '../models/login.model';
import {Paths} from '../../admin/admin-paths';
import { stringify } from '@angular/compiler/src/util';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AuthService } from '../services/auth.service';
import {LoaderService} from '../../admin/services/loader.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  winAccount : string;

  

  @ViewChild('loginForm') loginForm: NgForm;
  loginData: any;
  submitted = false;

  isLoginSuccess = false;
  userName: string;
  password: string;
  responseName: string = '';
  responseRoleName: string = '';
  loginStatus: boolean;
  invalidLogin: boolean = false;
  invalidPassword: boolean = false;
  currentToken: any;
  @ViewChild("focusElem") focusTag: ElementRef;

  ngOnInit(): void {
    // localStorage.setItem('loginStatus',"false");
    // this.loginStatus = false;
    // console.log(this.loginStatus);
    // this.loginService.setLoginStatus(this.loginStatus);
    // setTimeout(()=>{
    //   this.focusTag.nativeElement.focus()
    // }, 100);
    // debugger;
  }

  constructor(private loginService: LoginService, public loaderService: LoaderService, private router: Router) { 
    debugger;
    this.loginService.getUserName().subscribe(account => {
      this.winAccount = account;
      debugger;
      this.loginService.getAuthenticatedUser(this.winAccount).subscribe((data)=>{
        if(data){
          debugger;
          this.getLoggedInResponse(data);
        }
      })
      debugger;
    })
  }
  // getLoginDetails(){
  //   this.loginService.getLoginDetails().subscribe(
  //     (data:LoginModel ) =>  {
  //         this.loginData = JSON.stringify(data);
  //     }
  //   )
  // }
  checkEmail(){
    this.invalidLogin = false;
  }
  checkPwd(){
    this.invalidLogin = false;
  }

  getLoggedInResponse(data){
    if(data==''){
                
      this.loginData = data;
      
      this.loginService.setMenu(this.loginData.menuDetails); 
      
      this.loginService.setToken(this.loginData.token);
      this.loginService.curToken.subscribe(d => {                    
        console.log("cur token value : "+d);
        this.currentToken = d;
      });
      //
      this.responseName = this.loginData.name;
      this.responseRoleName = this.loginData.roleName;
      
      this.loginService.setLoggedInUser(this.responseName);
      this.loginService.setLoggedRole(this.responseRoleName);
      // if((this.userName=="ashwani.kumar@infinite.com" && this.password=="pass@1234") || (this.userName=="admin@infinite.com" && this.password=="pass@1234")){
        this.submitted = true;
        this.isLoginSuccess = true;
        this.invalidLogin = false;
        console.log("Name : "+this.responseName );
        console.log("Role Name : "+this.responseRoleName);
 
        localStorage.setItem('currentUser', JSON.stringify(data));
        localStorage.setItem('loginStatus',"true");
        this.loginStatus = Boolean(localStorage.getItem('loginStatus'));
        console.log(this.loginStatus);
        this.loginService.setLoginStatus(this.loginStatus);
        this.loginService.loginStatus.subscribe(d => {
          console.log(" login status "+d);
        //  
        });
        //
        this.router.navigate(['/dashboard'])
      //}         
    }
  }

  onSubmit() {

    this.userName = this.loginForm.value.emailId;
    this.password = this.loginForm.value.password;

    console.log("username : "+this.userName);
    console.log("password : "+this.password);
    console.log("Login path : "+Paths.loginPath);
     this.loginService.getLoginDetails(this.userName, this.password).subscribe(
            (data:LoginResponseModel ) =>  {
              if(data){                
                this.loginData = data;                
                this.loginService.setMenu(this.loginData.menuDetails);                 
                this.loginService.setToken(this.loginData.token);
                this.loginService.curToken.subscribe(d => {                    
                  console.log("cur token value : "+d);
                  this.currentToken = d;
                });
                //
                this.responseName = this.loginData.name;
                this.responseRoleName = this.loginData.roleName;
                
                this.loginService.setLoggedInUser(this.responseName);
                this.loginService.setLoggedRole(this.responseRoleName);
                  this.submitted = true;
                  this.isLoginSuccess = true;
                  this.invalidLogin = false;
                  console.log("Name : "+this.responseName );
                  console.log("Role Name : "+this.responseRoleName);
           
                  localStorage.setItem('currentUser', JSON.stringify(data));
                  localStorage.setItem('loginStatus',"true");
                  this.loginStatus = Boolean(localStorage.getItem('loginStatus'));
                  console.log(this.loginStatus);
                  this.loginService.setLoginStatus(this.loginStatus);
                  this.loginService.loginStatus.subscribe(d => {
                    console.log(" login status "+d);
                  //  
                  });
                  //
                  this.router.navigate(['/dashboard'])
                //}         
              }
            },
            (err) => {
                this.invalidLogin = true;
            }
          );
   // }
   }
   

}

