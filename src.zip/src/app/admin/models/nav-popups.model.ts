
export interface IClientObj{
   clientId: string;
   clientName: string;
   isAdd: boolean;
   isUpdate: boolean;
}
export interface ISharedContractID{
   id: number;
}
