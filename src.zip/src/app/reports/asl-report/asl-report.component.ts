import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asl-report',
  templateUrl: './asl-report.component.html',
  styleUrls: ['./asl-report.component.css']
})
export class ASLReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
