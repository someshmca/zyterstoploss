
export interface ICustomer{
    customerId: number,
    firstName: string,
    lastName: string
}