import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-max-liability-report',
  templateUrl: './max-liability-report.component.html',
  styleUrls: ['./max-liability-report.component.css']
})
export class MAXLiabilityReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
