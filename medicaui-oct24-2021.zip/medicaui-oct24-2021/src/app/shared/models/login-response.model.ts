export class LoginResponseModel{
    constructor(
    public name: string,
    public roleName: string){

    }
}

